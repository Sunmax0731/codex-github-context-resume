# 起動・復帰・Codex/GitHub文脈管理 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | VSCodeExtension |
| No. | 3 |
| 分野 | Codex・GitHub作業導線 |
| アイデア | 起動・復帰・Codex/GitHub文脈管理 |
| リポジトリ名 | codex-github-context-resume |
| 概要 | タスク、ローカルサーバー、ワークスペース切替、スニペット、プロンプト、Codex履歴、GitHub作業、Skill.md、Agents.md、README、TODO、DESIGNを同じ文脈ビューにまとめる。 |
| 課題 | 作業開始時に起動手順、GitHub状態、Codex履歴、読むべき文書を別々に確認する必要がある。 |
| 類似サービス・アプリ | GitHub Pull Requests, GitLens, Continue, Project Manager, Sourcegraph |
| 差別化ポイント | CodexとGitHubの作業文脈、ローカル文書、起動導線を同じVS Codeパネルに束ねる。 |

## 目的

このZIPには、`VSCodeExtension` 領域のアイデア `起動・復帰・Codex/GitHub文脈管理` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
