# 02 仕様: 起動・復帰・Codex/GitHub文脈管理

## プロダクト範囲

- 領域: VSCodeExtension
- リポジトリ名: codex-github-context-resume
- 分野: Codex・GitHub作業導線
- 目標: 次の課題を軽減する: 作業開始時に起動手順、GitHub状態、Codex履歴、読むべき文書を別々に確認する必要がある。
- 差別化ポイント: CodexとGitHubの作業文脈、ローカル文書、起動導線を同じVS Codeパネルに束ねる。

## 主要フロー

1. ユーザーが入力データ、ファイル、ページ文脈、オブジェクト、作業項目を選択する。
2. システムがメタデータ、状態、候補を読み取り、正規化する。
3. ユーザーが設定、フィルター、対象、プリセットを調整する。
4. システムが処理、検証、比較、生成、保存のいずれかを実行する。
5. システムが結果、ログ、警告、次の操作を表示する。
6. ユーザーが書き出し、保存、再試行、スキップ、レビュー完了のいずれかを行う。

## 画面 / 操作面

- ダッシュボード: 現在の対象、状態、警告、次の操作を表示する。
- ワークベンチ: 入力、プレビュー、設定、実行、結果確認を扱う。
- 履歴: 実行ログ、判断、失敗、出力先を記録する。
- 設定: プリセット、出力先、権限、連携設定を管理する。

## データモデル案

| エンティティ | 主な項目 | 目的 |
| --- | --- | --- |
| Project | id, name, rootPath, createdAt, updatedAt | 作業単位 |
| Item | id, title, sourcePath, tags, status, metadata | 対象項目 |
| Preset | id, name, settings, targetType | 再利用可能な設定 |
| RunLog | id, itemId, action, result, errors, createdAt | 実行証跡 |
| Export | id, runId, outputPath, format, checksum | 出力管理 |

## エラー

- EmptyInput: 入力または対象が見つからない。
- InvalidFormat: 未対応または破損した入力。
- PermissionDenied: ファイル、API、ホストアプリの権限が不足している。
- PartialFailure: 一部の項目が失敗した。
- CompletedWithWarnings: 警告付きで完了した。
