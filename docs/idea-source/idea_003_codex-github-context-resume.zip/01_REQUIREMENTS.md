# 01 要件定義: 起動・復帰・Codex/GitHub文脈管理

## 背景

タスク、ローカルサーバー、ワークスペース切替、スニペット、プロンプト、Codex履歴、GitHub作業、Skill.md、Agents.md、README、TODO、DESIGNを同じ文脈ビューにまとめる。

## 課題

作業開始時に起動手順、GitHub状態、Codex履歴、読むべき文書を別々に確認する必要がある。

## 対象ユーザー

- `Codex・GitHub作業導線` 領域で継続的に作業するユーザー。
- 既存の代替手段が広すぎる、重すぎる、または分断されていると感じているユーザー。
- 入力、確認、処理、出力、履歴を一つの流れで扱いたいユーザー。

## ユーザー価値

- ツールや画面を行き来する負担を減らす。
- 判断、設定、結果、エラーを後から追える形で残す。
- 製品上で次の差別化ポイントが分かるようにする: CodexとGitHubの作業文脈、ローカル文書、起動導線を同じVS Codeパネルに束ねる。

## MVP機能要件

- FR-1: ユーザーは対象データまたは作業項目を入力、選択、取り込みできる。
- FR-2: ユーザーは取り込んだ内容を一覧、プレビュー、状態ビューで確認できる。
- FR-3: 中核となる `Codex・GitHub作業導線` の処理を実行できる。
- FR-4: 結果、判断、エラー、履歴を保存または書き出しできる。
- FR-5: 失敗時は原因、再試行、スキップ、復旧操作を表示する。

## Non-functional Requirements

- Keep small personal datasets responsive.
- Require confirmation or preview before destructive actions.
- Do not send local files, credentials, or assets externally without explicit intent.
- Keep enough logs for troubleshooting and repeatability.

## Out of Scope for MVP

- Replacing every feature of similar products.
- Complex team permission management.
- Automation that depends on unverified third-party terms or unstable pages.

## Acceptance Criteria

- The main flow works from input to output/save.
- Normal, failure, and cancel paths can be tested.
- The differentiation is visible in UI or workflow behavior.
