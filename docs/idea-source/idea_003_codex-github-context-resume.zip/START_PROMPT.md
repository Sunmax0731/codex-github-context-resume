あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Plugins
- 領域: VSCodeExtension
- No.: 3
- 分野: Codex・GitHub作業導線
- アイデア: 起動・復帰・Codex/GitHub文脈管理
- リポジトリ名: codex-github-context-resume

## 元アイデア

- 概要: タスク、ローカルサーバー、ワークスペース切替、スニペット、プロンプト、Codex履歴、GitHub作業、Skill.md、Agents.md、README、TODO、DESIGNを同じ文脈ビューにまとめる。
- 課題: 作業開始時に起動手順、GitHub状態、Codex履歴、読むべき文書を別々に確認する必要がある。
- 類似サービス・アプリ: GitHub Pull Requests, GitLens, Continue, Project Manager, Sourcegraph
- 差別化ポイント: CodexとGitHubの作業文脈、ローカル文書、起動導線を同じVS Codeパネルに束ねる。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- ホストアプリのバージョン、権限、パネル/メニュー導線、ファイル入出力境界を明確にする。
- ホストアプリのデータモデル、選択状態、書き出しパイプライン、失敗パターンを前提に設計する。
- サンプルプロジェクトと実際のホストアプリ操作で検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
