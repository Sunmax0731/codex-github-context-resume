# Idea Source

参照元 ZIP: `D:\AI\VSCodeExtension\created_idea_003_codex-github-context-resume\idea_003_codex-github-context-resume.zip`。一部に文字化けがあったため、正式docsは `PICKUP_100_IDEAS.md` とドメインガイドから再構成した。

正式docsはこのディレクトリの原文コピーではなく、正常な日本語で再構成した `docs/*.md` を正とする。
